/**
 * FARM FLOW - First Time Setup Script
 * Run this ONCE after setting up the database to create your Super Admin account
 * 
 * Usage: node setup.js
 */

require('dotenv').config();
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
const readline = require('readline');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (q) => new Promise(resolve => rl.question(q, resolve));

async function setup() {
  console.log('\n🌿 Farm Flow - First Time Setup\n');
  console.log('This will create your Super Admin account.\n');

  try {
    // Run schema
    const fs = require('fs');
    const schema = fs.readFileSync('./src/db/schema.sql', 'utf8');
    await pool.query(schema);
    console.log('✅ Database tables created.\n');

    // Check if admin already exists
    const existing = await pool.query('SELECT COUNT(*) FROM admins');
    if (parseInt(existing.rows[0].count) > 0) {
      console.log('⚠️  Admin account already exists. Skipping setup.\n');
      rl.close();
      pool.end();
      return;
    }

    // Get admin details
    const username = await question('Enter Admin Username: ');
    const fullName = await question('Enter Full Name: ');
    const password = await question('Enter Password (min 8 chars): ');

    if (!username || !fullName || !password) {
      console.log('❌ All fields are required.');
      rl.close();
      pool.end();
      return;
    }

    if (password.length < 8) {
      console.log('❌ Password must be at least 8 characters.');
      rl.close();
      pool.end();
      return;
    }

    const hash = await bcrypt.hash(password, 12);

    await pool.query(`
      INSERT INTO admins (username, password_hash, full_name, role)
      VALUES ($1, $2, $3, 'super_admin')
    `, [username.toLowerCase().trim(), hash, fullName]);

    console.log('\n✅ Super Admin created successfully!');
    console.log(`   Username: ${username.toLowerCase().trim()}`);
    console.log(`   Role: Super Admin`);
    console.log('\n🚀 Farm Flow backend is ready. Run: node server.js\n');

  } catch (err) {
    console.error('❌ Setup failed:', err.message);
  }

  rl.close();
  pool.end();
}

setup();
