# 🌿 Farm Flow Backend API

**Connecting Farms to Markets**

---

## 📋 API Endpoints Summary

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/login | Admin login |
| GET | /api/auth/me | Get current admin info |
| POST | /api/auth/logout | Logout |

### Users
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/users/register | Register new user |
| GET | /api/users/search | Search users |
| GET | /api/users/:farmflowId | Get full profile |
| PATCH | /api/users/:farmflowId | Update user details |
| PATCH | /api/users/:farmflowId/status | Suspend/remove/reactivate |
| GET | /api/users/stats/dashboard | Dashboard statistics |

### Admins (Super Admin only)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/admins | List all admins |
| POST | /api/admins | Create new admin |
| PATCH | /api/admins/:id/toggle | Activate/deactivate admin |
| PATCH | /api/admins/change-password | Change own password |
| GET | /api/admins/logs | View activity logs |

---

## 🚀 Setup Instructions

### Step 1 — Install Requirements
- Node.js v18+: https://nodejs.org
- PostgreSQL v14+: https://postgresql.org

### Step 2 — Clone & Install
```bash
npm install
```

### Step 3 — Create Database
```sql
-- In PostgreSQL:
CREATE DATABASE farmflow_db;
```

### Step 4 — Configure Environment
```bash
cp .env.example .env
# Edit .env and fill in your DATABASE_URL and JWT_SECRET
```

### Step 5 — First Time Setup (creates Super Admin)
```bash
node setup.js
```

### Step 6 — Start Server
```bash
node server.js
# or for development:
npm run dev
```

---

## 🆔 Farm Flow ID Format

```
FF-[TYPE]-[COUNTRY]-[STATE]-[0000000001]
```

| Type | Code | Example |
|------|------|---------|
| Farmer | FRM | FF-FRM-NG-KST-0000000001 |
| Buyer | BYR | FF-BYR-NG-KDN-0000000001 |
| Agent | AGT | FF-AGT-IN-MHR-0000000001 |
| Logistics | LOG | FF-LOG-NG-KST-0000000001 |
| Admin | ADM | FF-ADM-NG-KST-0000000001 |

- Each TYPE + COUNTRY + STATE combination has its own counter
- Numbers go from 0000000001 to 9999999999 (10 billion per zone)
- Globally unique — no two users can ever have the same ID

---

## ☁️ Recommended Hosting (Free Tier)

| Service | What For | Link |
|---------|----------|------|
| **Railway** | Backend server | railway.app |
| **Supabase** | PostgreSQL database | supabase.com |
| **Render** | Alternative backend | render.com |

---

## 🔐 Security Notes

- JWT tokens expire after 8 hours
- All admin actions are logged
- Passwords are hashed with bcrypt (12 rounds)
- Change JWT_SECRET in .env before going live
- Never share your .env file
