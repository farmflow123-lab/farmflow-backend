-- ============================================
-- FARM FLOW DATABASE SCHEMA
-- Run this file in PostgreSQL to setup database
-- ============================================

-- Create database (run this separately as superuser)
-- CREATE DATABASE farmflow_db;

-- ============================================
-- ADMINS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role VARCHAR(20) DEFAULT 'super_admin' CHECK (role IN ('super_admin', 'customer_care')),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  last_login TIMESTAMP
);

-- ============================================
-- ID COUNTERS TABLE (for generating unique IDs)
-- One row per TYPE+COUNTRY+STATE combination
-- ============================================
CREATE TABLE IF NOT EXISTS id_counters (
  id SERIAL PRIMARY KEY,
  user_type VARCHAR(10) NOT NULL,   -- FRM, BYR, AGT, LOG, ADM
  country_code VARCHAR(5) NOT NULL, -- NG, IN, US, etc.
  state_code VARCHAR(5) NOT NULL,   -- KST, KDN, MHR, etc.
  last_number BIGINT DEFAULT 0,
  UNIQUE(user_type, country_code, state_code)
);

-- ============================================
-- USERS TABLE (all 4 types + shared fields)
-- ============================================
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  farmflow_id VARCHAR(40) UNIQUE NOT NULL,  -- e.g. FF-FRM-NG-KST-0000000001
  user_type VARCHAR(15) NOT NULL CHECK (user_type IN ('farmer', 'buyer', 'agent', 'logistics')),
  
  -- Personal Info
  full_name VARCHAR(150) NOT NULL,
  phone_number VARCHAR(20) NOT NULL,
  nin VARCHAR(20),                          -- National ID Number
  passport_photo_url TEXT,
  
  -- Location
  country VARCHAR(60) NOT NULL,
  country_code VARCHAR(5) NOT NULL,
  state VARCHAR(60) NOT NULL,
  state_code VARCHAR(5) NOT NULL,
  lga VARCHAR(60),
  village_town VARCHAR(100),
  full_address TEXT,
  
  -- Banking
  bank_name VARCHAR(60),
  account_number VARCHAR(20),
  account_name VARCHAR(150),
  
  -- Status
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'removed', 'pending')),
  suspension_end_date DATE,
  suspension_reason TEXT,
  
  -- Timestamps
  registered_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  registered_by_admin_id INTEGER REFERENCES admins(id)
);

-- ============================================
-- FARMERS EXTRA INFO
-- ============================================
CREATE TABLE IF NOT EXISTS farmer_details (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  farm_location TEXT,
  farm_size VARCHAR(50),
  produce_types TEXT[],   -- Array: ['Maize', 'Millet', 'Soybean']
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- LOGISTICS EXTRA INFO
-- ============================================
CREATE TABLE IF NOT EXISTS logistics_details (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  vehicle_type VARCHAR(60),
  vehicle_plate VARCHAR(20),
  vehicle_capacity_bags INTEGER,
  coverage_area TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- AGENTS EXTRA INFO
-- ============================================
CREATE TABLE IF NOT EXISTS agent_details (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  coverage_lga TEXT,
  coverage_state VARCHAR(60),
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- VIOLATIONS LOG
-- ============================================
CREATE TABLE IF NOT EXISTS violations (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  farmflow_id VARCHAR(40),
  violation_type VARCHAR(100) NOT NULL,
  description TEXT,
  action_taken VARCHAR(50),
  recorded_by_admin_id INTEGER REFERENCES admins(id),
  recorded_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- ADMIN ACTIVITY LOG
-- ============================================
CREATE TABLE IF NOT EXISTS admin_logs (
  id SERIAL PRIMARY KEY,
  admin_id INTEGER REFERENCES admins(id),
  action VARCHAR(100) NOT NULL,
  target_user_id INTEGER,
  target_farmflow_id VARCHAR(40),
  details TEXT,
  ip_address VARCHAR(45),
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- INDEXES for fast search
-- ============================================
CREATE INDEX IF NOT EXISTS idx_users_farmflow_id ON users(farmflow_id);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone_number);
CREATE INDEX IF NOT EXISTS idx_users_type ON users(user_type);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_users_country_state ON users(country_code, state_code);
CREATE INDEX IF NOT EXISTS idx_users_name ON users(full_name);
CREATE INDEX IF NOT EXISTS idx_violations_user ON violations(user_id);

-- ============================================
-- DEFAULT SUPER ADMIN (change password after setup!)
-- Password: FarmFlow2024! (bcrypt hashed)
-- ============================================
-- NOTE: Run setup.js to create the first admin account securely
