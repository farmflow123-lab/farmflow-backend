const express = require('express');
const router = express.Router();
const db = require('../db/db');
const { requireAuth, requireSuperAdmin, logActivity } = require('../middleware/auth');
const { generateFarmFlowId } = require('../utils/idGenerator');

/**
 * POST /api/users/register
 * Register a new user (Farmer, Buyer, Agent, Logistics)
 */
router.post('/register', requireAuth, async (req, res) => {
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');

    const {
      userType, fullName, phoneNumber, nin,
      country, countryCode, state, stateCode, lga, villageTown, fullAddress,
      bankName, accountNumber, accountName,
      // Farmer specific
      farmLocation, farmSize, produceTypes,
      // Logistics specific
      vehicleType, vehiclePlate, vehicleCapacityBags, coverageArea,
      // Agent specific
      coverageLga, coverageState,
    } = req.body;

    // Validate required fields
    if (!userType || !fullName || !phoneNumber || !country || !state) {
      return res.status(400).json({ success: false, message: 'Missing required fields: userType, fullName, phoneNumber, country, state.' });
    }

    const validTypes = ['farmer', 'buyer', 'agent', 'logistics'];
    if (!validTypes.includes(userType)) {
      return res.status(400).json({ success: false, message: `Invalid user type. Must be: ${validTypes.join(', ')}` });
    }

    // Check duplicate phone
    const dupCheck = await client.query(
      'SELECT farmflow_id FROM users WHERE phone_number = $1',
      [phoneNumber]
    );
    if (dupCheck.rows.length) {
      return res.status(409).json({
        success: false,
        message: `Phone number already registered. Existing ID: ${dupCheck.rows[0].farmflow_id}`
      });
    }

    // Generate unique Farm Flow ID
    const farmflowId = await generateFarmFlowId(userType, country, state);

    // Insert user
    const userResult = await client.query(`
      INSERT INTO users (
        farmflow_id, user_type, full_name, phone_number, nin,
        country, country_code, state, state_code, lga, village_town, full_address,
        bank_name, account_number, account_name,
        registered_by_admin_id
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
      RETURNING id, farmflow_id, registered_at
    `, [
      farmflowId, userType, fullName, phoneNumber, nin || null,
      country, countryCode || country.substring(0,2).toUpperCase(),
      state, stateCode || state.substring(0,3).toUpperCase(),
      lga || null, villageTown || null, fullAddress || null,
      bankName || null, accountNumber || null, accountName || null,
      req.admin.id
    ]);

    const newUser = userResult.rows[0];

    // Insert type-specific details
    if (userType === 'farmer') {
      await client.query(`
        INSERT INTO farmer_details (user_id, farm_location, farm_size, produce_types)
        VALUES ($1, $2, $3, $4)
      `, [newUser.id, farmLocation || null, farmSize || null, produceTypes || null]);
    }

    if (userType === 'logistics') {
      await client.query(`
        INSERT INTO logistics_details (user_id, vehicle_type, vehicle_plate, vehicle_capacity_bags, coverage_area)
        VALUES ($1, $2, $3, $4, $5)
      `, [newUser.id, vehicleType || null, vehiclePlate || null, vehicleCapacityBags || null, coverageArea || null]);
    }

    if (userType === 'agent') {
      await client.query(`
        INSERT INTO agent_details (user_id, coverage_lga, coverage_state)
        VALUES ($1, $2, $3)
      `, [newUser.id, coverageLga || null, coverageState || null]);
    }

    await client.query('COMMIT');

    await logActivity(req.admin.id, 'REGISTER_USER', newUser.id, farmflowId,
      `Registered ${userType}: ${fullName}`, req.ip);

    res.status(201).json({
      success: true,
      message: `${userType.charAt(0).toUpperCase() + userType.slice(1)} registered successfully.`,
      farmflowId,
      userId: newUser.id,
      registeredAt: newUser.registered_at,
    });

  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  } finally {
    client.release();
  }
});

/**
 * GET /api/users/search
 * Search users — by ID, name, phone, type, country, state, status
 */
router.get('/search', requireAuth, async (req, res) => {
  try {
    const { farmflowId, name, phone, userType, country, state, status, page = 1, limit = 20 } = req.query;

    let conditions = [];
    let params = [];
    let paramIndex = 1;

    if (farmflowId) {
      conditions.push(`u.farmflow_id ILIKE $${paramIndex++}`);
      params.push(`%${farmflowId}%`);
    }
    if (name) {
      conditions.push(`u.full_name ILIKE $${paramIndex++}`);
      params.push(`%${name}%`);
    }
    if (phone) {
      conditions.push(`u.phone_number ILIKE $${paramIndex++}`);
      params.push(`%${phone}%`);
    }
    if (userType) {
      conditions.push(`u.user_type = $${paramIndex++}`);
      params.push(userType);
    }
    if (country) {
      conditions.push(`(u.country ILIKE $${paramIndex} OR u.country_code ILIKE $${paramIndex})`);
      params.push(`%${country}%`);
      paramIndex++;
    }
    if (state) {
      conditions.push(`(u.state ILIKE $${paramIndex} OR u.state_code ILIKE $${paramIndex})`);
      params.push(`%${state}%`);
      paramIndex++;
    }
    if (status) {
      conditions.push(`u.status = $${paramIndex++}`);
      params.push(status);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (parseInt(page) - 1) * parseInt(limit);

    const countResult = await db.query(
      `SELECT COUNT(*) FROM users u ${whereClause}`,
      params
    );

    params.push(parseInt(limit), offset);
    const usersResult = await db.query(`
      SELECT u.id, u.farmflow_id, u.user_type, u.full_name, u.phone_number,
             u.country, u.state, u.lga, u.status, u.registered_at
      FROM users u
      ${whereClause}
      ORDER BY u.registered_at DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `, params);

    res.json({
      success: true,
      total: parseInt(countResult.rows[0].count),
      page: parseInt(page),
      limit: parseInt(limit),
      users: usersResult.rows,
    });

  } catch (err) {
    console.error('Search error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/users/:farmflowId
 * Get full profile of a user by Farm Flow ID
 */
router.get('/:farmflowId', requireAuth, async (req, res) => {
  try {
    const { farmflowId } = req.params;

    const userResult = await db.query(`
      SELECT u.*,
        a.username as registered_by_admin
      FROM users u
      LEFT JOIN admins a ON a.id = u.registered_by_admin_id
      WHERE u.farmflow_id = $1
    `, [farmflowId.toUpperCase()]);

    if (!userResult.rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const user = userResult.rows[0];

    // Get type-specific details
    let extraDetails = null;
    if (user.user_type === 'farmer') {
      const fd = await db.query('SELECT * FROM farmer_details WHERE user_id = $1', [user.id]);
      extraDetails = fd.rows[0] || null;
    } else if (user.user_type === 'logistics') {
      const ld = await db.query('SELECT * FROM logistics_details WHERE user_id = $1', [user.id]);
      extraDetails = ld.rows[0] || null;
    } else if (user.user_type === 'agent') {
      const ad = await db.query('SELECT * FROM agent_details WHERE user_id = $1', [user.id]);
      extraDetails = ad.rows[0] || null;
    }

    // Get violations history
    const violations = await db.query(`
      SELECT v.*, a.username as recorded_by
      FROM violations v
      LEFT JOIN admins a ON a.id = v.recorded_by_admin_id
      WHERE v.user_id = $1
      ORDER BY v.recorded_at DESC
    `, [user.id]);

    await logActivity(req.admin.id, 'VIEW_PROFILE', user.id, farmflowId, null, req.ip);

    res.json({
      success: true,
      user,
      extraDetails,
      violations: violations.rows,
    });

  } catch (err) {
    console.error('Get user error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * PATCH /api/users/:farmflowId/status
 * Suspend, remove, or reactivate a user
 */
router.patch('/:farmflowId/status', requireAuth, async (req, res) => {
  try {
    const { farmflowId } = req.params;
    const { status, reason, suspensionDays } = req.body;

    const validStatuses = ['active', 'suspended', 'removed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: `Status must be: ${validStatuses.join(', ')}` });
    }

    const userResult = await db.query('SELECT id, full_name, user_type FROM users WHERE farmflow_id = $1', [farmflowId]);
    if (!userResult.rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const user = userResult.rows[0];
    let suspensionEndDate = null;

    if (status === 'suspended' && suspensionDays) {
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + parseInt(suspensionDays));
      suspensionEndDate = endDate.toISOString().split('T')[0];
    }

    await db.query(`
      UPDATE users SET status = $1, suspension_end_date = $2, suspension_reason = $3, updated_at = NOW()
      WHERE farmflow_id = $4
    `, [status, suspensionEndDate, reason || null, farmflowId]);

    // Log violation if suspending or removing
    if (status === 'suspended' || status === 'removed') {
      await db.query(`
        INSERT INTO violations (user_id, farmflow_id, violation_type, description, action_taken, recorded_by_admin_id)
        VALUES ($1, $2, $3, $4, $5, $6)
      `, [user.id, farmflowId, reason || 'Admin action', reason || null, status, req.admin.id]);
    }

    await logActivity(req.admin.id, `STATUS_${status.toUpperCase()}`, user.id, farmflowId, reason, req.ip);

    res.json({
      success: true,
      message: `User ${status} successfully.`,
      farmflowId,
      status,
      suspensionEndDate,
    });

  } catch (err) {
    console.error('Status update error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * PATCH /api/users/:farmflowId
 * Update user details
 */
router.patch('/:farmflowId', requireAuth, async (req, res) => {
  try {
    const { farmflowId } = req.params;
    const updates = req.body;

    const allowedFields = [
      'full_name', 'phone_number', 'nin', 'lga', 'village_town', 'full_address',
      'bank_name', 'account_number', 'account_name'
    ];

    const setClause = [];
    const params = [];
    let i = 1;

    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        setClause.push(`${field} = $${i++}`);
        params.push(updates[field]);
      }
    }

    if (!setClause.length) {
      return res.status(400).json({ success: false, message: 'No valid fields to update.' });
    }

    setClause.push(`updated_at = NOW()`);
    params.push(farmflowId);

    await db.query(
      `UPDATE users SET ${setClause.join(', ')} WHERE farmflow_id = $${i}`,
      params
    );

    await logActivity(req.admin.id, 'UPDATE_USER', null, farmflowId, JSON.stringify(updates), req.ip);

    res.json({ success: true, message: 'User updated successfully.' });

  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/users/stats/dashboard
 * Dashboard statistics
 */
router.get('/stats/dashboard', requireAuth, async (req, res) => {
  try {
    const stats = await db.query(`
      SELECT
        COUNT(*) FILTER (WHERE user_type = 'farmer') as total_farmers,
        COUNT(*) FILTER (WHERE user_type = 'buyer') as total_buyers,
        COUNT(*) FILTER (WHERE user_type = 'agent') as total_agents,
        COUNT(*) FILTER (WHERE user_type = 'logistics') as total_logistics,
        COUNT(*) FILTER (WHERE status = 'active') as total_active,
        COUNT(*) FILTER (WHERE status = 'suspended') as total_suspended,
        COUNT(*) FILTER (WHERE status = 'removed') as total_removed,
        COUNT(*) as total_users,
        COUNT(*) FILTER (WHERE registered_at >= NOW() - INTERVAL '7 days') as new_this_week,
        COUNT(*) FILTER (WHERE registered_at >= NOW() - INTERVAL '30 days') as new_this_month
      FROM users
    `);

    res.json({ success: true, stats: stats.rows[0] });
  } catch (err) {
    console.error('Stats error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
